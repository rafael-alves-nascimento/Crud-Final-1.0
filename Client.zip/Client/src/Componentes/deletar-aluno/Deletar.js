import React,{useState} from "react";
import {useNavigate} from 'react-router-dom'
import "./Deletar.css"
import api from '../Api/api'

// {}
const Deletar = () => {
    const Navigate = useNavigate();

    function redCadastrar () {
        localStorage.clear();
        Navigate("/Cadastrar");
    }
    function redDeletar () {
        localStorage.clear();
        Navigate("/Deletar");
    }
    function redEditar () {
        localStorage.clear();
        Navigate("/Editar");
    }
    
    const [matricula,setMatricula] = useState("")

    const matriculaAluno = (values) => {
        setMatricula(values)
    }  

    const dadosInputs = (value) => {
        setMatricula((prevValue) => ({
            ...prevValue,
          [value.target.name] : value.target.value,
        }));
    }


    const handleClickButton = () => {
        api.delete(matricula.deletar_matricula).then(({data})=> {
            console.log(data)
            alert("Aluno deletado do banco")
        }) 
      }
    

  return (
    <div className="login-deletar">
        <div className="box-deletar">
            <img src="user-login4.png" alt="imagem-login" className="img-deletar" />
            <br />
            <br />

            <div className="input-style">
                <label>Informe o N da matricula do aluno que voce deseja Deletar</label><br />
                <input  className="input-deletar" type="text" placeholder="Informe o N da matricula" name="deletar_matricula" onChange={dadosInputs} />         
            </div>
            <br />
    
            <button className="login-button" type="submit"  onClick={() => handleClickButton()}>Deletar</button> 
            <br/>
            <br/>

            <div className="botao">
                <button href="#" className="cadastrar-deletar" onClick={redCadastrar}>Cadastrar</button>
                <button href="#" className="deletar-deletar" onClick={redDeletar}>Deletar</button>
                <button href="#" className="editar-deletar" onClick={redEditar}>Editar</button>
            </div>

        </div>
    </div>
  );
};

export default Deletar;