import React,{useState} from "react";
import "./Cadastrar.css"
import {useNavigate} from 'react-router-dom'
import Axios from "axios";

// {}
const Cadastrar = () => {

  const Navigate = useNavigate();

  function redCadastrar () {
      localStorage.clear();
      Navigate("/Cadastrar");
  }
  function redDeletar () {
      localStorage.clear();
      Navigate("/Deletar");
  }
  function redEditar () {
      localStorage.clear();
      Navigate("/Editar");
  }
  const [values,setValues] = useState("")

  const dadosInputs = (value) => {
      setValues((prevValue) => ({
          ...prevValue,
        [value.target.name] : value.target.value,
      }));
  }

  const handleClickButton = () => {
    Axios.post("http://localhost:3005/alunos", {
        "Nome": values.nome,
        matricula: values.matricula,
        "Turma": values.turma,
        "Nota": values.nota,
    }).then((response) => {
        console.log(response)
        alert("Aluno cadastrado no banco")
    });
  }

  // console.log(values)
  return (
    <div className="login-cadastrar">
        <div className="box-cadastrar">
            <img src="user-login4.png" alt="imagem-login" className="img-cadastrar" />

            <div className="input-style">
                <label>Nome</label><br />
                <input  className="input-cadastrar" name="nome" type="text" placeholder="Informe o nome"
                onChange={dadosInputs}/>         
            </div>

          <div className="input-style">
                <label>Matricula</label><br />
                <input  className="input-cadastrar" name="matricula" type="text" placeholder="Informe o N da matricula" onChange={dadosInputs} />
            </div>

          <div className="input-style">
                <label>Turma</label><br />
                <input className="input-cadastrar" name="turma" type="text" placeholder="informe a Turma" onChange={dadosInputs} />
            </div>


          <div className="input-style">
                <label>Nota</label><br />
                <input className="input-cadastrar" name="nota" type="text" placeholder="informe a Turma" onChange={dadosInputs} />
            </div>
          <br />

          <button className="login-button" type="submit" onClick={() => handleClickButton()}>Cadastrar</button> <br/>
          <br/>

          <div className="botao">
                <button href="#" className="cadastrar-cadastrar" onClick={redCadastrar}>Cadastrar</button>
                <button href="#" className="deletar-cadastrar" onClick={redDeletar}>Deletar</button>
                <button href="#" className="editar-cadastrar" onClick={redEditar}>Editar</button>
            </div>

        </div>
    </div>
  );
};

export default Cadastrar;