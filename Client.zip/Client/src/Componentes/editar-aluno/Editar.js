import React,{useState} from "react";
import "./Editar.css"
import {useNavigate} from 'react-router-dom'
import api from '../Api/api'

const Editar = () => {
    const Navigate = useNavigate();

    function redCadastrar () {
        localStorage.clear();
        Navigate("/Cadastrar");
    }
    function redDeletar () {
        localStorage.clear();
        Navigate("/Deletar");
    }
    function redEditar () {
        localStorage.clear();
        Navigate("/Editar");
    }
    const [values,setValues] = useState("")

    const dadosInputs = (value) => {
        setValues((prevValue) => ({
            ...prevValue,
          [value.target.name] : value.target.value,
        }));
    }

    const handleClickButton = () => {
        api.put(values.Matricula_edit, {
            "Nome": values.nome,
            matricula: values.matricula,
            "Turma": values.turma,
            "Nota": values.nota,
        }).then(({data})=> {
            console.log(data)
            alert("Informações alteradas no banco")
        }) 
      }
    //   console.log(values)
  return (
        <div className="login-editar">
            <div className="box-editar">
                <img src="user-login4.png" alt="imagem-login" className="img-editar" />
                <br />
                <div className="input-style">
                    <label>Informe o N da matricula do aluno que voce deseja editar</label><br />
                    <input  className="input-editar" type="text" placeholder="Informe o N da matricula" name="Matricula_edit" onChange={dadosInputs} />         
                </div>

            <div className="input-style">
                    <label>Nome</label><br />
                    <input  className="input-editar" type="text" placeholder="Informe o nome" name="nome" onChange={dadosInputs}/>         
                </div>
            <br />



            <div className="input-style">
                    <label>Turma</label><br />
                    <input className="input-editar" type="text" placeholder="informe a Turma" name="turma" onChange={dadosInputs}/>
                </div>
            <br />
            <div className="input-style">
                    <label>Nota</label><br />
                    <input className="input-cadastrar" name="nota" type="text" placeholder="informe a Nota do aluno" onChange={dadosInputs} />
                </div>
            <br/>
            

            <button className="login-button" type="submit" onClick={() => handleClickButton()}>Editar</button> <br/>
            <br/>
                <div className="botao">
                    <button href="#" className="cadastrar-editar" onClick={redCadastrar}>Cadastrar</button>
                    <button href="#" className="deletar-editar" onClick={redDeletar}>Deletar</button>
                    <button href="#" className="editar-editar" onClick={redEditar}>Editar</button>
                </div>

            </div>
        </div>
  );
};

export default Editar;