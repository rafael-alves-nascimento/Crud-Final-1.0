import React,{useState, useEffect} from "react";
import "./Mostrar.css";
import api from "../Api/api";


const MostrarAlunos = () => {
    const [dados,setDados] = useState([])

    useEffect(() => {
        api.get("").then(({data})=> {
            setDados(data)
        })
    },[]);

    console.log(dados)

    function listaTabela(){
      let tbody = document.getElementById("tbody");
      // for()
    }

  return (
    <div className="Get">
      <div className="Header-mostrar">
        <h5 className="Titulo">Alunos Cadastrados</h5>
      </div>
      <div className="Conteudo">
          <table>  {/* Tabela */}
            <thead>
              <th>Matricula</th> {/* Colunas verticais */}
              <th>Nome</th>
              <th>Turma</th>
              <th>Nota</th> 
            </thead>
            <tbody className="tbody" >

            </tbody>
          </table>
        </div>
    </div>
  );
};

export default MostrarAlunos;
