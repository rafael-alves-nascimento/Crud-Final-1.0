import Rotas from './routes/routes'
import "./App.css" 

function App() {
  return (
    <div className="App">
      <Rotas/>
    </div>
  );
}

export default App;
